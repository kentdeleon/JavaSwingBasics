package model;

import java.util.ArrayList;
import java.util.List;

public class Database {

	private List<Person> persons;
	
	public Database() {
		this.persons = new ArrayList<>();
	}
	
	public void addPerson(Person person) {
		persons.add(person);
	}
	
	public List<Person> getAllPerson(){
		return persons;
	}
}
