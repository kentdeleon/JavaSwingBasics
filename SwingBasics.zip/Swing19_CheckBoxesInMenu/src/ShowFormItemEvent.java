import java.util.EventObject;

public class ShowFormItemEvent extends EventObject {

	private boolean isShowFormItemCheck;
	
	public ShowFormItemEvent(Object source) {
		super(source);
	}

	public ShowFormItemEvent(Object source, boolean isShowFormItemCheck) {
		super(source);
		this.isShowFormItemCheck = isShowFormItemCheck;
	}

	public boolean isShowFormItemCheck() {
		return isShowFormItemCheck;
	}

	public void setShowFormItemCheck(boolean isShowFormItemCheck) {
		this.isShowFormItemCheck = isShowFormItemCheck;
	}
	
	

}
