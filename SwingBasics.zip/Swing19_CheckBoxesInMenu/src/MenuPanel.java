import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

public class MenuPanel extends JPanel {

	private static final long serialVersionUID = 4034785946747632409L;
	private JMenuBar menuBar;
	private ShowFormItemListener showFormItemListener;
	
	public MenuPanel() {
		setLayout(new BorderLayout());
		
		menuBar = createMenuBar();
		
		add(menuBar, BorderLayout.LINE_START);
	}
	
	public void setListener(ShowFormItemListener listener) {
		this.showFormItemListener = listener;
	}
	
	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new JMenu("File");
		
		JMenuItem exportDataItem = new JMenuItem("Export Data...");
		JMenuItem importDataItem = new JMenuItem("Import Data...");
		JMenuItem exitItem = new JMenuItem("Exit");
		
		fileMenu.add(exportDataItem);
		fileMenu.add(importDataItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
		
		JMenu windowMenu = new JMenu("Window");
		
		JMenu showMenu = new JMenu("Show");
		JCheckBoxMenuItem showFormItem = new JCheckBoxMenuItem("Person Form");
		showFormItem.setSelected(true);
		
		//add listener to showFormItem
		showFormItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isShowFormItemSelected = showFormItem.isSelected();
				
				ShowFormItemEvent ev = new ShowFormItemEvent(this, isShowFormItemSelected);
				
				if(showFormItemListener != null) {
					showFormItemListener.showFormItemEventOccured(ev);
				}
				
				//other way below 
//				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) e.getSource();
//				formPanel.setVisible(menuItem.isSelected());
				
				
			}
			
		});
		
		windowMenu.add(showMenu);
		showMenu.add(showFormItem);
		
		menuBar.add(fileMenu);
		menuBar.add(windowMenu);

		
		return menuBar;
	}
	
	

}
