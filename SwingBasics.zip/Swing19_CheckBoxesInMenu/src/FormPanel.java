import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class FormPanel extends JPanel {

	private static final long serialVersionUID = -1505265457916809810L;

	private JLabel nameLabel;
	private JLabel occupationLabel;
	private JTextField nameField;
	private JTextField occupationField;
	private JButton submitButton;
	private FormListener formListener;
	private JLabel ageCategoryLabel;
	private JList ageList;
	private JComboBox employeeType;
	private JCheckBox citizenCheck;
	private JTextField taxField;
	private JLabel taxLabel;
	
	private JRadioButton maleRadio;
	private JRadioButton femaleRadio;
	private ButtonGroup genderGroup;

	public FormPanel() {
		Dimension dim = getPreferredSize();
		dim.width = 250;
		setPreferredSize(dim);

		// adding labels and fields
		nameLabel = new JLabel("Name: ");
		occupationLabel = new JLabel("Occupation: ");
		nameField = new JTextField(10);
		occupationField = new JTextField(10);

		ageCategoryLabel = new JLabel("Age Category: ");
		// adding List Box
		ageList = new JList();
		ageList.setPreferredSize(new Dimension(110, 66));
		ageList.setBorder(BorderFactory.createEtchedBorder());

		DefaultListModel<AgeCategory> ageModel = new DefaultListModel<>();
		ageModel.addElement(new AgeCategory(0, "under 18"));
		ageModel.addElement(new AgeCategory(1, "18 to 65"));
		ageModel.addElement(new AgeCategory(2, "65 or over"));
		ageList.setModel(ageModel);
		ageList.setSelectedIndex(1);

		// adding combo box
		employeeType = new JComboBox();

		DefaultComboBoxModel<String> employeeModel = new DefaultComboBoxModel<>();
		employeeModel.addElement("Employed");
		employeeModel.addElement("Self-Employed");
		employeeModel.addElement("Unemployed");
		employeeType.setModel(employeeModel);
		employeeType.setSelectedIndex(2);

		// adding check box
		citizenCheck = new JCheckBox();

		// adding field related to check box
		taxField = new JTextField(10);
		taxLabel = new JLabel("Tax ID: ");
		taxField.setEnabled(false);
		taxLabel.setEnabled(false);

		citizenCheck.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				boolean isTicked = citizenCheck.isSelected();
				if (isTicked) {
					taxField.setEnabled(true);
					taxLabel.setEnabled(true);
				} else {
					taxField.setEnabled(false);
					taxLabel.setEnabled(false);
				}

			}
		});
		
		//setting up radio buttons
		maleRadio = new JRadioButton("male");
		femaleRadio = new JRadioButton("female");
		genderGroup = new ButtonGroup();
		
		maleRadio.setActionCommand("male");
		femaleRadio.setActionCommand("female");
		
		maleRadio.setSelected(true);
		
		//setup gender radios
		genderGroup.add(maleRadio);
		genderGroup.add(femaleRadio);
		
		// adding button
		submitButton = new JButton("Submit");

		// adding action listener to button
		submitButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String name = nameField.getText();
				String occupation = occupationField.getText();

				// adding object reference to ageList selected value
				AgeCategory ageCategory = (AgeCategory) ageList.getSelectedValue();
				int ageCategoryKey = ageCategory.getKey();

				// adding object reference to employeeType combo box value
				String empCategory = (String) employeeType.getSelectedItem();

				// adding object reference to UsCitizen check box
				boolean isUsCitizen = (boolean) citizenCheck.isSelected();
				
				//adding object reference to gender Selected Radios
				String genderSelected = genderGroup.getSelection().getActionCommand();

				// Add Form Event
				FormEvent ev;
				if (isUsCitizen) {
					 ev = new FormEvent(this, name, occupation, ageCategoryKey, empCategory, isUsCitizen, (String) taxField.getText(), genderSelected);
				}else {
					 ev = new FormEvent(this, name, occupation, ageCategoryKey, empCategory,isUsCitizen, genderSelected);
				}
				

				if (formListener != null) {
					formListener.formEventOccured(ev);

				}
			}
		});

		setBorder(BorderFactory.createTitledBorder("Add Person"));

		Border innerBorder = BorderFactory.createTitledBorder("Add Person");
		Border outerBorder = BorderFactory.createEmptyBorder(5, 5, 5, 5);
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));

		layoutComponents();
	}

	public void layoutComponents() {
		setLayout(new GridBagLayout());

		GridBagConstraints gc = new GridBagConstraints();

		// FIRST ROW//
		gc.gridx = 0;
		gc.gridy = 0;

		gc.weightx = 1;
		gc.weighty = 0.1;

		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(nameLabel, gc);

		gc.gridx = 1;
		gc.gridy = 0;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(nameField, gc);

		// SECOND ROW//
		gc.gridy++;

		gc.gridx = 0;
		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(occupationLabel, gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(occupationField, gc);

		// THIRD ROW//
		gc.gridy++;

		gc.gridx = 0;
		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(new JLabel("Employee Type:"), gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(employeeType, gc);

		// FOURTH ROW//
		gc.gridy++;

		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(ageCategoryLabel, gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(ageList, gc);

		// FIFTH ROW//
		gc.gridy++;

		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(new JLabel("U.S. Citizen: "), gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(citizenCheck, gc);

		// SIXTH ROW//
		gc.gridy++;

		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(taxLabel, gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(taxField, gc);


		// SeVENTH ROW//
		gc.gridy++;

		gc.weightx = 1;
		gc.weighty = 0.1;
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(new JLabel("Gender: "), gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(maleRadio, gc);
		
		// EIGHT ROW//
		gc.gridy++;

		gc.weightx = 1;
		gc.weighty = 0.05;
//		gc.gridx = 0;
//		gc.anchor = GridBagConstraints.FIRST_LINE_END;
//		gc.insets = new Insets(0, 0, 0, 5);
//		add(new JLabel("Gender: "), gc);

		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(femaleRadio, gc);
		
		// LAST ROW//
		gc.gridy++;

		gc.gridx = 1;
		gc.weightx = 1;
		gc.weighty = 2.0;

		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 5);
		add(submitButton, gc);
	}

	public void setFormListener(FormListener formListener) {
		this.formListener = formListener;
	}
}

class AgeCategory {
	private int key;
	private String value;

	public AgeCategory(int key, String value) {
		this.key = key;
		this.value = value;
	}

	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return value;
	}

}
