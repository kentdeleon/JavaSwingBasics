package com.kent;

import org.hamcrest.BaseMatcher;
import org.hamcrest.Description;
import org.hamcrest.Matcher;

public class CustomMatcher extends BaseMatcher<SampleClass>{

	private SampleClass expected;
	
	public static Matcher<SampleClass> excitedSample(SampleClass expected){
		return new CustomMatcher(expected);
	}
	
	public CustomMatcher(SampleClass expected) {
		this.expected = expected;
	}
	
	@Override
	public boolean matches(Object o) {
		SampleClass s = (SampleClass) o;
		if(s.getIntValue() > 10) {
			return s.getStringValue().contains(expected.getStringValue());
		}
		
		return true;
	}

	@Override
	public void describeTo(Description d) {
		d.appendText("Customize description");
		
	}

}
