package com.kent;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.kent.test.AssertThat.AssertThatBasic;
import com.kent.test.AssertThat.AssertThatCollection;
import com.kent.test.AssertThat.AssertThatCustom;

@RunWith(Suite.class)
@SuiteClasses({AssertThatBasic.class, AssertThatCollection.class, AssertThatCustom.class})
public class TestSuiteExample {

}
