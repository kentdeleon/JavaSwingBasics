package com.kent.test.AssertThat;


import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.equalTo;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.kent.CustomMatcher;
import com.kent.SampleClass;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AssertThatCustom {

	@Test
	public void basicCustomMatcher() {
		SampleClass tester = new SampleClass(29, "custom matcher test");
		SampleClass expected = new SampleClass(1, "custom");
		
		Assert.assertThat("Run a custom matcher", tester, CustomMatcher.excitedSample(expected));
	}
	
	@Test
	public void customMatcherAdvanced() {
		SampleClass tester = new SampleClass(29, "custom matcher test");
		SampleClass expected = new SampleClass(1, "custom");
		
		Assert.assertThat("Run a custom matcher", tester, either(CustomMatcher.excitedSample(expected)).or(equalTo(expected)));
	}
}
