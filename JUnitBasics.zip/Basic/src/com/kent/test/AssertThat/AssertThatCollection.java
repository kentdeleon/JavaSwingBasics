package com.kent.test.AssertThat;

import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.everyItem;
import static org.hamcrest.CoreMatchers.hasItem;
import static org.hamcrest.CoreMatchers.hasItems;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.startsWith;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AssertThatCollection {

	@Test
	public void _CollectionContains() {
		String[] testArray = {"a", "b", "c", "d", "e"};
		Collection<String> tested = Arrays.asList(testArray);
		Assert.assertThat("Is the item contained", tested, hasItem("c"));
	}
	
	@Test
	public void _CheckCollection() {
		String[] testArray = {"a", "b", "c", "d", "e"};
		List<String> tested = Arrays.asList(testArray);
		Assert.assertThat("Any item meets the criteria", tested, hasItems("b", "e"));
	}
	
	@Test
	public void _CollectionSearch() {
		String[] testArray = {"dog", "cat", "tiger", "mouse", "unicorn"};
		Set<String> tested = new HashSet<>(Arrays.asList(testArray));
		Assert.assertThat("Any item meets the criteria", tested, hasItem(startsWith("uni")));
	}
	
	@Test
	public void _CollectionFilter() {
		String[] testArray = {"dog", "cat", "tiger", "mouse", "unicorn"};
		List<String> tested = Arrays.asList(testArray);
		Assert.assertThat("All items meets the criteria", tested, everyItem(not(endsWith("fish"))));
	}
}
