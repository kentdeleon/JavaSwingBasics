package com.kent.test.AssertThat;

import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.anyOf;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.either;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.startsWith;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AssertThatCombination {

	@Test
	public void _AllOf() {
		String tested = "(side bar)!";
		Assert.assertThat("Many criteria", tested, allOf(startsWith("("), containsString("bar"), endsWith("!")));

		
	}

	@Test
	public void _AnyOf() {
		String tested = "does this, being a fragment, contain punctionation?";
		Assert.assertThat("Many criteria", tested,
				anyOf(containsString(","), containsString("."), containsString("!"), containsString("?")));
	}

	@Test
	public void _Combination() {
		String tested = "this should avoid special characters";
		Assert.assertThat("Many criteria", tested,
				not(anyOf(containsString(","), containsString("."), containsString("!"), containsString("?"))));
	}
	
	@Test
	public void _Regex() {
		String tested = "this should avoid special characters";
		Assert.assertTrue("Using a regex instead", tested.matches("^[^<>%$,.!?]*$"));
	}
	
	@Test
	public void _Either() {
		String tested = "(side bar)!";
		Assert.assertThat("Either", tested, either(endsWith("!")).or(startsWith("(")).and(notNullValue()));
	}
}
