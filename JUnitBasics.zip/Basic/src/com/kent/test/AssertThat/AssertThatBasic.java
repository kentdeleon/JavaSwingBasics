package com.kent.test.AssertThat;

import static org.hamcrest.CoreMatchers.anything;
import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.endsWith;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.instanceOf;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.isA;
import static org.hamcrest.CoreMatchers.not;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.CoreMatchers.sameInstance;
import static org.hamcrest.CoreMatchers.startsWith;
import static org.hamcrest.CoreMatchers.theInstance;

import java.io.Serializable;

import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import com.kent.SampleClass;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AssertThatBasic {

	@Test
	public void _Anything() {
		String tested = "Hello matcher logic";
		String check = "matcher";
		Assert.assertThat("Anything passes", tested, anything(check));
	}

	@Test
	public void _Null() {
		String tested = null;
		Assert.assertThat("Is it null?", tested, nullValue());
	}

	@Test
	public void _NotNull() {
		String tested = "";
		Assert.assertThat("Is it not null?", tested, notNullValue());
	}

	@Test
	public void _EqualTo() {
		String tested = "equals";
		String check = "equals";
		Assert.assertThat("Are they equals? ", tested, equalTo(check));
		Assert.assertThat("Are they equals?", tested, is(check));
	}

	@Test
	public void _NotEqualTo() {
		String tested = "seperated";
		String check = "equals";
		Assert.assertThat("They are not equal", tested, not(check));
	}

	@Test
	public void _Same() {
		SampleClass first = new SampleClass(3, "same");
		SampleClass same = first;
		Assert.assertThat("==?", first, sameInstance(same));
		Assert.assertThat("==?", first, theInstance(same));
	}

	@Test
	public void _InstanceOf() {
		String tested = "Excited!";
		Assert.assertThat("Is instanceof?", tested, instanceOf(Serializable.class));
		Assert.assertThat("Is a?", tested, isA(Serializable.class));
	}

	@Test
	public void _ContainsString() {
		String tested = "Hello matcher logic";
		String check = "matcher";
		Assert.assertThat("Does it contain a string?", tested, containsString(check));
	}

	@Test
	public void _StartsWith() {
		String tested = "(side bar)";
		String check = "("; 
		Assert.assertThat("Starts with", tested, startsWith(check));
	}
	
	@Test
	public void _EndsWith() {
		String tested = "Excited!";
		String check = "!";
		Assert.assertThat("Ends with", tested, endsWith(check));
	}
	
	@Test
	public void _Negation() {
		String tested = "Neutral";
		String check = "!";
		Assert.assertThat("Negation", tested, not(endsWith(check)));
	}
}
