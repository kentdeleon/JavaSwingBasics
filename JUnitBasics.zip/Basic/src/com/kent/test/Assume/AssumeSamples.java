package com.kent.test.Assume;

import static org.hamcrest.CoreMatchers.containsString;
import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.not;

import org.junit.Assume;
import org.junit.Before;
import org.junit.Test;

public class AssumeSamples {

	@Test
	public void assumeBoolean() {
		Assume.assumeFalse("This should be false", false);
		Assume.assumeTrue("This should be true", true);
		System.out.println("Boolean ok");
	}
	
	@Test
	public void notNull() {
		Assume.assumeNotNull("one", "two", "many more");
		System.out.println("None were null");
	}
	
	@Test
	public void noException() {
		try {
		
			Integer.parseInt("1");
		}catch(NumberFormatException e) {
			Assume.assumeNoException("Should not fail", e);
		}
		System.out.println("No exception happened");
	}
	
	@Test
	public void matcherWithThat() {
		Assume.assumeThat("check any criteria", "my string", containsString("my"));
		System.out.println("That turned out OK");
	}
	
	@Test
	public void badInputData() {
		int testData = 0;
		Assume.assumeThat("Must not be zero", testData, not(equalTo(0)));
		
		int answer = 10/testData;
	}
	
	@Before
	public void assumeInSetup() {
		Assume.assumeTrue("it works in setup too", true);
	}
}
