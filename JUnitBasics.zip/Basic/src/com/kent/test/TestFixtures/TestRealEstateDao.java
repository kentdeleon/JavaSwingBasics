package com.kent.test.TestFixtures;

import org.junit.Before;
import org.junit.BeforeClass;

public class TestRealEstateDao {

//	private static ConfigurationFactory config;
//	private RealEstateDao dao;
//	private RealEstate sample;
//	
//	@BeforeClass
//	public static void setupHibernate() {
//		config = new ConfigurationFactory();
//	}
//	
//	@Before
//	public void setupDAO() {
//		dao = new RealEstateDao(config.getSessionFactory());
//	}
//	
//	@Before
//	public void setupSample() {
//		sample = createRealEstate();
//	}
}
