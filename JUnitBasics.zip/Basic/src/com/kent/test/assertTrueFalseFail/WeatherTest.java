package com.kent.test.assertTrueFalseFail;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.*;

import org.junit.Test;

import com.kent.Weather;

public class WeatherTest {

	private Weather weather = new Weather(8);
	
	@Test
	public void showAssertTrue() {
		assertTrue("No Rainbow Today", weather.isItSunnyToday() && weather.willItRainToday());
		System.out.println("OK, test the rainbow stuff");
	}
	
	@Test
	public void showAssertFalse() {
		assertFalse("Unsafe to drive", !(weather.isItFreezingToday() && weather.willItRainToday()));
		System.out.println("Test the new vehicle");
	}
	
	@Test 
	public void showFail() {
		System.out.println(weather.isItFreezingToday());
		if(weather.isItFreezingToday() || weather.willItRainToday()) {
			fail("Weather is bad, call off our plans");
		}
	}
}
