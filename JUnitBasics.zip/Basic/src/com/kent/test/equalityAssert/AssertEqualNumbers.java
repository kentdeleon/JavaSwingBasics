package com.kent.test.equalityAssert;

import static junit.framework.Assert.assertEquals;

import org.junit.Test;

import junit.framework.Assert;

public class AssertEqualNumbers {

	@Test
	public void a_AssertLongEqualAssert() {
		int longValue = 10;
		Assert.assertEquals(longValue, longValue);
		
	}
}
