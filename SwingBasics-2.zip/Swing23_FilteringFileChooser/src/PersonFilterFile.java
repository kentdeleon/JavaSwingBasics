import java.io.File;

import javax.swing.filechooser.FileFilter;

public class PersonFilterFile extends FileFilter {

	@Override
	public boolean accept(File file) {
		String name = file.getName();
		String fileExt = Utils.getFileExtension(name);
		
		if(file.isDirectory()) {
			return true;
		}
		if(fileExt != null && fileExt.equals("per")) {
			return true;
		}
		return false;
	}

	@Override
	public String getDescription() {
		return "Person database files (*.per)";
	}

}
