import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class MainFrame extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private TextPanel textPanel;
	private ToolBar toolBar;
	private FormPanel formPanel;
	private MenuPanel menuPanel;
	

	public MainFrame(String title) {
		super(title);
		setLayout(new BorderLayout());

		toolBar = new ToolBar();
		textPanel = new TextPanel();
		formPanel = new FormPanel();
		menuPanel = new MenuPanel();
		
		

		// setting menuPanel
		menuPanel.setListener(new ShowFormItemListener() {
			@Override
			public void showFormItemEventOccured(ShowFormItemEvent ev) {
				formPanel.setVisible(ev.isShowFormItemCheck());
			}
		});

		toolBar.setListener(new StringListener() {
			@Override
			public void textEmitted(String text) {
				textPanel.appendText(text);
			}
		});

		formPanel.setFormListener(new FormListener() {
			public void formEventOccured(FormEvent e) {
				String name = e.getName();
				String occupation = e.getOccupation();
				int ageCategoryKey = e.getAgeCategoryKey();
				String employeeCategory = e.getEmployeeCategory();
				boolean isUsCitizen = e.getUsCitizen();
				String gender = e.getGender();

				if (isUsCitizen) {
					String taxId = e.getTaxId();
					textPanel.appendText("--------------------\n" + "NAME: " + name + "\n" + "OCCUPATION: " + occupation
							+ "\n" + "AGE CATEGORY: " + ageCategoryKey + "\n" + "EMPLOYEE CATEGORY: " + employeeCategory
							+ "\n" + "U.S. CITIZEN: YES \n" + "TAX ID: " + taxId + "\n" + "GENDER: " + gender + "\n"
							+ "--------------------");
				} else {
					textPanel.appendText("--------------------\n" + "NAME: " + name + "\n" + "OCCUPATION: " + occupation
							+ "\n" + "AGE CATEGORY: " + ageCategoryKey + "\n" + "EMPLOYEE CATEGORY: " + employeeCategory
							+ "\n" + "U.S. CITIZEN: NO \n" + "GENDER: " + gender + "\n" + "--------------------");
				}

			}
		});
		add(formPanel, BorderLayout.WEST);
		add(toolBar, BorderLayout.NORTH);
		add(textPanel, BorderLayout.CENTER);
		add(menuPanel, BorderLayout.NORTH);

		setMinimumSize(new Dimension(500, 400));
		setSize(600, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

}
