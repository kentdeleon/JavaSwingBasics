import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JPanel;

public class ToolBar extends JPanel implements ActionListener {

	private JButton helloButton;
	private JButton goodByeButton;
	//private TextPanel textPanel;
	private StringListener listener;

	public ToolBar() {
		setBorder(BorderFactory.createEtchedBorder());
		helloButton = new JButton("Hello Button");
		goodByeButton = new JButton("GoodBye Button");

		helloButton.addActionListener(this);
		goodByeButton.addActionListener(this);

		setLayout(new FlowLayout(FlowLayout.LEFT));

		add(helloButton);
		add(goodByeButton);

	}

	public void setListener(StringListener listener) {
		this.listener = listener;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton clicked = (JButton) e.getSource();
		
		
		if(clicked == helloButton) {
			if(listener != null) {
				listener.textEmitted("Hello\n");
			}
		}else if(clicked == goodByeButton) {
			if(listener != null) {
				listener.textEmitted("GoodBye\n");
			}
		}
		
	}

}
