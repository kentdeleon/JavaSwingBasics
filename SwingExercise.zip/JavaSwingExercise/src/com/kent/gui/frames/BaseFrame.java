package com.kent.gui.frames;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.JFrame;

import com.kent.gui.eventlisteners.BaseComponentEvent;
import com.kent.gui.eventlisteners.FormEvent;
import com.kent.gui.eventlisteners.FormListener;
import com.kent.gui.panels.FormPanel;
import com.kent.gui.panels.MenuPanel;
import com.kent.gui.panels.OutputPanel;

public class BaseFrame extends JFrame {
	
	private static final long serialVersionUID = -1641120732217459607L;
	
	private FormPanel formPanel;
	private OutputPanel outputPanel;
	private MenuPanel menuPanel;
	private FormListener formListener;

	
	
	public BaseFrame(String appName) {
		super(appName);
		
		buildFrameAndLoadComponents();
		buildActionListenerToComponents();
	}
	
	private void buildFrameAndLoadComponents() {
		setLayout(new BorderLayout());
		setMinimumSize(new Dimension(500, 400));
		setSize(700, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		
		formPanel = new FormPanel();
		add(formPanel, BorderLayout.WEST);
		
		outputPanel = new OutputPanel();
		add(outputPanel, BorderLayout.CENTER);
		
		menuPanel = new MenuPanel();
		add(menuPanel, BorderLayout.NORTH);
	}
	
	private void buildActionListenerToComponents() {
		formListener = new FormListener();
		formListener.setOutputPanel(outputPanel);
		formPanel.setFormListener(formListener);
		menuPanel.setFormPanel(formPanel);
		
	}
}
