package com.kent.gui.eventlisteners;

public class FormEvent extends BaseComponentEvent {

	private static final long serialVersionUID = -8058704244970827176L;

	private String name;
	private String occupation;
	private String employeeType;
	private String genderSelected;
	private int ageCategoryKey;
	private String taxId;
	private boolean usCitizenship;

	public FormEvent(Object obj) {
		super(obj);
	}
	
	public FormEvent(Object obj, String name, String occupation, String employeeType, String genderSelected, int ageCategoryKey) {
		super(obj);
		this.name = name;
		this.occupation = occupation;
		this.employeeType = employeeType;
		this.genderSelected = genderSelected;
		this.ageCategoryKey = ageCategoryKey;
	}
	
	public FormEvent(Object obj, String name, String occupation, String employeeType, String genderSelected, int ageCategoryKey, boolean usCitizenship,  String taxId) {
		super(obj);
		this.name = name;
		this.occupation = occupation;
		this.employeeType = employeeType;
		this.genderSelected = genderSelected;
		this.ageCategoryKey = ageCategoryKey;
		this.usCitizenship = usCitizenship;
		this.taxId = taxId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public String getGenderSelected() {
		return genderSelected;
	}

	public void setGenderSelected(String genderSelected) {
		this.genderSelected = genderSelected;
	}

	
	public int getAgeCategoryKey() {
		return ageCategoryKey;
	}

	public void setAgeCategoryKey(int ageCategoryKey) {
		this.ageCategoryKey = ageCategoryKey;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public boolean isUsCitizenship() {
		return usCitizenship;
	}

	public void setUsCitizenship(boolean usCitizenship) {
		this.usCitizenship = usCitizenship;
	}

	@Override
	public String toString() {
		return "FormEvent [name=" + name + ", occupation=" + occupation + ", employeeType=" + employeeType + "]";
	}
	
	

}
