package com.kent.gui.eventlisteners;

import java.util.EventListener;



public interface BaseComponentListener extends EventListener {

	public void ComponentEventOccured(BaseComponentEvent ev);




}
