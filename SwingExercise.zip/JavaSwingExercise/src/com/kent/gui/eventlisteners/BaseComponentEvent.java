package com.kent.gui.eventlisteners;

import java.util.EventObject;

public class BaseComponentEvent extends EventObject {

	private static final long serialVersionUID = -610907597816662175L;

	public BaseComponentEvent(Object obj) {
		super(obj);
	}

}
