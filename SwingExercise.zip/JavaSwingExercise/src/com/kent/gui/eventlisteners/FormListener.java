package com.kent.gui.eventlisteners;

import javax.swing.JPanel;

import com.kent.gui.panels.OutputPanel;

public class FormListener implements BaseComponentListener {

	private JPanel outputPanel;

	
	@Override
	public void ComponentEventOccured(BaseComponentEvent ev) {
		FormEvent formEvent = (FormEvent) ev;
		String name = formEvent.getName();
		String occupation = formEvent.getOccupation();
		String employeeType = formEvent.getEmployeeType();
		String gender = formEvent.getGenderSelected();
		int ageCategoryKey = formEvent.getAgeCategoryKey();
		String taxId = formEvent.getTaxId();
		String text = "";
		
		if(taxId != null) {
		 text = "---------------------\n" + 
					  "Name: " + name + "\n" + 
					  "Occupation: " + occupation + "\n" +
					  "Employee Type: " + employeeType + "\n" + 
					  "Gender: " + gender + "\n" + 
					  "Age Category: " + ageCategoryKey + "\n" + 
					  "U.S. Citizen: YES \n" + 
					  "Tax Id: " + taxId;
			
		}else {
			 text = "---------------------\n" + 
					  "Name: " + name + "\n" + 
					  "Occupation: " + occupation + "\n" +
					  "Employee Type: " + employeeType + "\n" + 
					  "Gender: " + gender + "\n" + 
					  "Age Category: " + ageCategoryKey + "\n";
		}
		((OutputPanel) this.outputPanel).appendTextOutput(text);
		
	}



	public void setOutputPanel(JPanel outputPanel) {
		this.outputPanel = outputPanel;
	}




}
