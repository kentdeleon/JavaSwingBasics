package com.kent.gui.panels;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class OutputPanel extends JPanel {
	
	private JTextArea textArea;
	
	public OutputPanel() {
		//setup panel
		Border innerBorder = BorderFactory.createTitledBorder("Output Area");
		Border outerBorder = BorderFactory.createEmptyBorder(10, 0, 5, 10);
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		//setup panel layout
		setLayout(new BorderLayout());
		
		//addComponent
		textArea = new JTextArea();
		
		add(new JScrollPane(textArea), BorderLayout.CENTER);
	}
	
	public void appendTextOutput(String text) {
		textArea.append(text);
	}

}
