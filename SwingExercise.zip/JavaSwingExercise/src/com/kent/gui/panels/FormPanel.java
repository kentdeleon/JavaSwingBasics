package com.kent.gui.panels;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.kent.gui.eventlisteners.BaseComponentListener;
import com.kent.gui.eventlisteners.FormEvent;

public class FormPanel extends JPanel {

	private JLabel nameLabel;
	private JTextField nameField;
	
	private JLabel occupationLabel;
	private JTextField occupationField;
	
	private JLabel employeeTypeLabel;
	private JComboBox<String> employeeType;
	
	private JButton submitButton;
	
	private JLabel genderLabel;
	private JRadioButton maleRadio;
	private JRadioButton femaleRadio;
	private ButtonGroup genderGroup;
	
	private JLabel ageCategoryLabel;
	private JList<AgeCategory> ageList;
	
	private JLabel usCitizenLabel;
	private JCheckBox usCitizenCheck;
	
	private JLabel taxIdLabel;
	private JTextField taxIdField;
	
	private BaseComponentListener formListener;
	
	public FormPanel() {
		//setup panel
		Dimension dim = getPreferredSize();
		dim.width = 300;
		setPreferredSize(dim);
		
		setupFormComponents();
		layoutComponents();
		addComponentsListener();	

		Border innerBorder = BorderFactory.createTitledBorder("Add Person");
		Border outerBorder = BorderFactory.createEmptyBorder(10, 5, 5, 10);
		setBorder(BorderFactory.createCompoundBorder(outerBorder, innerBorder));
		
		
		
	}
	
	public void setupFormComponents() {
		nameLabel = new JLabel("Name: ");
		nameField = new JTextField(15);
		
		occupationLabel = new JLabel("Occupation: ");
		occupationField = new JTextField(15);
		
		employeeTypeLabel = new JLabel("Employee Type: ");
		employeeType = new JComboBox<>();
		DefaultComboBoxModel<String> employeeModel = new DefaultComboBoxModel<>();
		employeeModel.addElement("Employed");
		employeeModel.addElement("Self-Employed");
		employeeModel.addElement("Unemployed");
		employeeType.setModel(employeeModel);
		employeeType.setSelectedIndex(0);
		
		genderLabel = new JLabel("Gender: ");
		maleRadio = new JRadioButton("Male");
		genderGroup = new ButtonGroup();
		femaleRadio = new JRadioButton("Female");
		maleRadio.setActionCommand("Male");
		femaleRadio.setActionCommand("Female");
		maleRadio.setSelected(true);
		genderGroup.add(maleRadio);
		genderGroup.add(femaleRadio);
		
		ageCategoryLabel = new JLabel("Age Category: ");
		ageList = new JList<>();
		ageList.setPreferredSize(new Dimension(110, 100));
		ageList.setBorder(BorderFactory.createEtchedBorder());
		DefaultListModel<AgeCategory> ageModel = new DefaultListModel<>();
		ageModel.addElement(new AgeCategory(1, "under 18 y/o"));
		ageModel.addElement(new AgeCategory(2, "18 to 65 y/o"));
		ageModel.addElement(new AgeCategory(3, "65 y/o and above"));
		ageList.setModel(ageModel);
		ageList.setSelectedIndex(1);
		
		usCitizenLabel = new JLabel("U.S. Citizen: ");
		usCitizenCheck = new JCheckBox();
		
		taxIdLabel = new JLabel("Tax ID: ");
		taxIdField = new JTextField(15);
		taxIdLabel.setEnabled(false);
		taxIdField.setEnabled(false);
		
		submitButton = new JButton("submit");
		submitButton.setMnemonic(KeyEvent.VK_ENTER);
		
	}
	
	public void layoutComponents() {
		setLayout(new GridBagLayout());
		GridBagConstraints gc = new GridBagConstraints();
		
		//First Row
		gc.gridx = 0;
		gc.gridy = 0;
		
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.fill = GridBagConstraints.NONE;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(nameLabel,gc);

		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0,0,0,0);
		add(nameField, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(occupationLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(occupationField, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(employeeTypeLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(employeeType, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(genderLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(maleRadio, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.05;
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(femaleRadio, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(ageCategoryLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(ageList, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(usCitizenLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(usCitizenCheck, gc);
		
		//Next Row
		gc.gridy++;
		gc.weightx = 1;
		gc.weighty = 0.1;
		
		gc.gridx = 0;
		gc.anchor = GridBagConstraints.FIRST_LINE_END;
		gc.insets = new Insets(0, 0, 0, 5);
		add(taxIdLabel, gc);
		
		gc.gridx = 1;
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 0);
		add(taxIdField, gc);
		
		//Last Row
		gc.gridy++;
		gc.gridx = 1;
		gc.weightx = 1;
		gc.weighty = 2.0;
		
		gc.anchor = GridBagConstraints.FIRST_LINE_START;
		gc.insets = new Insets(0, 0, 0, 5);
		add(submitButton, gc);
		
		
	}

	public void setFormListener(BaseComponentListener formListener) {
		this.formListener = formListener;
	}
	


	
	public void addComponentsListener() {
		
		usCitizenCheck.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isUSCitizenCheck = usCitizenCheck.isSelected();
				if(isUSCitizenCheck) {
					taxIdLabel.setEnabled(true);
					taxIdField.setEnabled(true);
				}else {
					taxIdLabel.setEnabled(false);
					taxIdField.setEnabled(false);
				}
				
			}
		});
		
		submitButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String name = nameField.getText();
				String occupation = occupationField.getText();
				String employeeCategory = (String) employeeType.getSelectedItem();
				String genderSelected = genderGroup.getSelection().getActionCommand();
				int ageCategoryKey = ageList.getSelectedIndex();
				boolean isUSCitizenCheck = usCitizenCheck.isSelected();
				String taxId = "";
				FormEvent ev  = null;
				
				if(isUSCitizenCheck) {
					taxId = taxIdField.getText();
					 ev = new FormEvent(this, name, occupation, employeeCategory, genderSelected, ageCategoryKey, isUSCitizenCheck, taxId);
				}else {
					 ev = new FormEvent(this, name, occupation, employeeCategory, genderSelected, ageCategoryKey);
				}
			

				if (formListener != null) {
					formListener.ComponentEventOccured(ev);
				}

			}
		});
	}
}

class AgeCategory{
	
	private int key;
	private String value;
	
	public AgeCategory(int key, String value) {
		this.key = key;
		this.value = value;
	}
	
	public int getKey() {
		return key;
	}
	public void setKey(int key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public String toString() {
		return value;
	}
	
	
}
