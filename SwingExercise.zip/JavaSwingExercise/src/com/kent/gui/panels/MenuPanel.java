package com.kent.gui.panels;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.KeyStroke;
import javax.swing.text.MaskFormatter;

import com.kent.gui.filefilters.PersonFileFilter;

public class MenuPanel extends JPanel {

	private static final long serialVersionUID = -6194590520685122890L;
	
	private JMenuBar menuBar;
	
	private JMenu fileMenu;
	private JMenuItem exportDataItem;
	private JMenuItem importDataItem;
	private JMenuItem exitItem;
	
	private JMenu windowMenu;
	private JMenu showMenu;
	private JCheckBoxMenuItem personFormItem;
	
	private JPanel formPanel;
	
	private JFileChooser fileChooser;
	
	public MenuPanel() {
		setLayout(new BorderLayout());
		setupMenuBar();
		add(menuBar, BorderLayout.CENTER);
		addComponentListener();
	}
	
	
	private JMenuBar setupMenuBar() {
		menuBar = new JMenuBar();
		
		//setting up fileMenu and the MenuItems under it
		fileMenu = new JMenu("File");
		exitItem = new JMenuItem("Exit");
		exportDataItem = new JMenuItem("Export Data...");
		importDataItem = new JMenuItem("Import Data...");
		fileMenu.add(exportDataItem);
		fileMenu.add(importDataItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
		
		exitItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		
		//setting up fileChooser
		fileChooser = new JFileChooser();
		
		//adding custom file filter
		fileChooser.addChoosableFileFilter(new PersonFileFilter());
		
		//adding action listener to the exportDataItem and importDataItem
		exportDataItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(fileChooser.showSaveDialog(MenuPanel.this) == JFileChooser.APPROVE_OPTION) {
					System.out.println(fileChooser.getSelectedFile());
				}
				
			}
		});
		
		importDataItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(fileChooser.showOpenDialog(MenuPanel.this) == JFileChooser.APPROVE_OPTION) {
					System.out.println(fileChooser.getSelectedFile());
				}
				
			}
		});
		
		//setting up Mnemonics and Accelerators
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exportDataItem.setMnemonic(KeyEvent.VK_E);
		importDataItem.setMnemonic(KeyEvent.VK_I);
		exitItem.setMnemonic(KeyEvent.VK_X);
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
	
		
		windowMenu = new JMenu("Window");
		showMenu = new JMenu("Show");
		personFormItem = new JCheckBoxMenuItem("Person Form");
		personFormItem.setSelected(true);
		windowMenu.add(showMenu);
		showMenu.add(personFormItem);

		menuBar.add(fileMenu);
		menuBar.add(windowMenu);
		

		return menuBar;
	}
	
	
	public void setFormPanel(JPanel formPanel) {
		this.formPanel = formPanel;
	}


	public void addComponentListener() {
		personFormItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				boolean showPersonForm = personFormItem.isSelected();
				
				FormPanel formToShow = (FormPanel) formPanel;
				formToShow.setVisible(showPersonForm);
			}
		});
	}
	
}
