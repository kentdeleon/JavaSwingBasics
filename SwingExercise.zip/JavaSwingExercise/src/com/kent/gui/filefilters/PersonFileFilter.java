package com.kent.gui.filefilters;

import java.io.File;

import javax.swing.filechooser.FileFilter;

import com.kent.gui.utilities.Utils;

public class PersonFileFilter extends FileFilter {

	@Override
	public boolean accept(File file) {
		String fileName = file.getName();
		String fileExtension = Utils.getFileExtension(fileName);
		
		if(file.isDirectory()) {
			return true;
		}
		
		if(fileExtension != null && fileExtension.equals("per")) {
			return true;
		}
		
		return false;
	}

	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Person database files (.per)";
	}

}
