package com.kent.gui.app;

import javax.swing.SwingUtilities;

import com.kent.gui.frames.BaseFrame;

public class SwingApp {

	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {	
			@Override
			public void run() {
				BaseFrame baseFrame = new BaseFrame("Swing App");
			}
		});
	}
}
