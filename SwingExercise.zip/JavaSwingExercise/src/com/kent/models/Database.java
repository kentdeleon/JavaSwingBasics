package com.kent.models;

import java.util.List;

public class Database {

	private List<Person> persons;
	
	private void addPerson(Person person) {
		this.persons.add(person);
	}
	
	private List<Person> getAllPersons(){
		return this.persons;
	}
}
