package com.kent.models;

public enum EmployeeCategory {
	unemployed,
	employed,
	selfEmployed,
	other
}
