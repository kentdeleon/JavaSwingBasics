package com.kent.models;

public enum Gender {
	male,
	female
}
