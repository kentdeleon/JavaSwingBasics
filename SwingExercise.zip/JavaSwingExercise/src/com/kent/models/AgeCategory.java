package com.kent.models;

public enum AgeCategory {

	child,
	adult,
	senior
}
