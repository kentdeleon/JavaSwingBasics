package com.kent.models;

public class Person {

	private static int count = 0;
	private int id;
	private String name;
	private String occupation;
	private String employeeType;
	private String genderSelected;
	private int ageCategoryKey;
	private String taxId;
	private boolean usCitizenship;
	
	
	public Person(String name, String occupation, String employeeType, String genderSelected, int ageCategoryKey,
			String taxId, boolean usCitizenship) {
		super();
		this.name = name;
		this.occupation = occupation;
		this.employeeType = employeeType;
		this.genderSelected = genderSelected;
		this.ageCategoryKey = ageCategoryKey;
		this.taxId = taxId;
		this.usCitizenship = usCitizenship;
		this.id = count;
		count++;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getOccupation() {
		return occupation;
	}


	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}


	public String getEmployeeType() {
		return employeeType;
	}


	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}


	public String getGenderSelected() {
		return genderSelected;
	}


	public void setGenderSelected(String genderSelected) {
		this.genderSelected = genderSelected;
	}


	public int getAgeCategoryKey() {
		return ageCategoryKey;
	}


	public void setAgeCategoryKey(int ageCategoryKey) {
		this.ageCategoryKey = ageCategoryKey;
	}


	public String getTaxId() {
		return taxId;
	}


	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}


	public boolean isUsCitizenship() {
		return usCitizenship;
	}


	public void setUsCitizenship(boolean usCitizenship) {
		this.usCitizenship = usCitizenship;
	}
	
	
}
