package model;

public enum EmployeeCategory {
	unemployed,
	employed,
	selfEmployed,
	other
}
