package model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Database {

	private List<Person> persons;
	
	public Database() {
		this.persons = new ArrayList<>();
	}
	
	public void addPerson(Person person) {
		persons.add(person);
		System.out.println("Successfully added a person" + person);
	}
	
	public List<Person> getAllPerson(){
		System.out.println("Getting all person from Database");
		return persons;
	}
	
	public void saveToFile(File file) throws IOException {
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		
		Person[] personsArr = persons.toArray(new Person[persons.size()]);
		
		oos.writeObject(personsArr);
		oos.close();
	}
	
	public void loadFromFile(File file) throws IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream(file);
		ObjectInputStream ois = new ObjectInputStream(fis);
		
		Person[] personsArr = (Person[]) ois.readObject();
		persons.clear();
		persons.addAll(Arrays.asList(personsArr));
		ois.close();
	}
}
