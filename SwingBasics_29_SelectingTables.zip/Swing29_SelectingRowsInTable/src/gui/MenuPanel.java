package gui;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.IOException;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

import controller.Controller;

public class MenuPanel extends JPanel {

	private static final long serialVersionUID = 4034785946747632409L;
	private JMenuBar menuBar;
	private ShowFormItemListener showFormItemListener;
	private JFileChooser fileChooser;
	private Controller controller;
	private TablePanel tablePanel;
	
	public void setTablePanel(TablePanel tablePanel) {
		this.tablePanel = tablePanel;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}

	public MenuPanel() {
		setLayout(new BorderLayout());
		
		menuBar = createMenuBar();
		
		add(menuBar, BorderLayout.CENTER);
	}
	
	public void setListener(ShowFormItemListener listener) {
		this.showFormItemListener = listener;
	}
	
	private JMenuBar createMenuBar() {
		JMenuBar menuBar = new JMenuBar();
		
		JMenu fileMenu = new JMenu("File");
		
		JMenuItem exportDataItem = new JMenuItem("Export Data...");
		JMenuItem importDataItem = new JMenuItem("Import Data...");
		JMenuItem exitItem = new JMenuItem("Exit");
		
		fileMenu.add(exportDataItem);
		fileMenu.add(importDataItem);
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
		
		JMenu windowMenu = new JMenu("Window");
		
		JMenu showMenu = new JMenu("Show");
		JCheckBoxMenuItem showFormItem = new JCheckBoxMenuItem("Person Form");
		showFormItem.setSelected(true);
		
		//FileChooser setup
		fileChooser = new JFileChooser();
		
		//Filtering file chooser
		fileChooser.addChoosableFileFilter(new PersonFilterFile());
		
		exportDataItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(fileChooser.showSaveDialog(MenuPanel.this) == JFileChooser.APPROVE_OPTION) {
					try {
						controller.saveToFile(fileChooser.getSelectedFile());
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(MenuPanel.this, "Could not save data to file", "Error", JOptionPane.ERROR_MESSAGE);
					}
					System.out.println(fileChooser.getSelectedFile());
				}
				
			}
		});
		
		importDataItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if(fileChooser.showOpenDialog(MenuPanel.this) == JFileChooser.APPROVE_OPTION) {
					try {
						controller.loadFromFile(fileChooser.getSelectedFile());
						tablePanel.refresh();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
						JOptionPane.showMessageDialog(MenuPanel.this, "Could not load data from file", "Error", JOptionPane.ERROR_MESSAGE);
					}
					System.out.println(fileChooser.getSelectedFile());
				}
				
			}
		});
		
		//add listener to showFormItem
		showFormItem.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				boolean isShowFormItemSelected = showFormItem.isSelected();
				
				ShowFormItemEvent ev = new ShowFormItemEvent(this, isShowFormItemSelected);
				
				if(showFormItemListener != null) {
					showFormItemListener.showFormItemEventOccured(ev);
				}
				
				//other way below 
//				JCheckBoxMenuItem menuItem = (JCheckBoxMenuItem) e.getSource();
//				formPanel.setVisible(menuItem.isSelected());
				
				
			}
			
		});
		
		windowMenu.add(showMenu);
		showMenu.add(showFormItem);
		
		menuBar.add(fileMenu);
		menuBar.add(windowMenu);

		//setting up mnemonic
		fileMenu.setMnemonic(KeyEvent.VK_F);
		exitItem.setMnemonic(KeyEvent.VK_X);
		
		//setting up accelerators
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X, ActionEvent.CTRL_MASK));
		exitItem.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				String text = JOptionPane.showInputDialog(MenuPanel.this, "Enter your username",
						"Enter User Name",
						JOptionPane.OK_OPTION|JOptionPane.INFORMATION_MESSAGE);
				System.out.println(text);
				
				int action = JOptionPane.showConfirmDialog(MenuPanel.this, 
						"Do you really want to exit the application?", "Confirm Exit", JOptionPane.OK_CANCEL_OPTION);
				if (action == JOptionPane.OK_OPTION) {
					System.exit(0);
				}
				
			}
		});
		
		return menuBar;
	}
	
	

}
