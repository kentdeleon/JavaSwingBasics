package gui;
import java.util.EventListener;

public interface ShowFormItemListener extends EventListener {

	public void showFormItemEventOccured(ShowFormItemEvent ev);
}
