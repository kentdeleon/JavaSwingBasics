package com.kent.hibernate.realstate;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.kent.realstate.hibernate.entities.Home;

public class HomeDAO {

	private SessionFactory sessionFactory = null;
	private Session session = null;
	private Transaction tx = null;
	private List<Home> homes = null;
	
	public List<Home> getAllHomeByPortfolioId(Long portfolio_id){
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();
			
			Query query = session.createQuery("SELECT h FROM Home h WHERE portfolio_id = ?");
			query.setParameter(0, portfolio_id);
			homes = query.list();

			tx.commit();
		}catch(Exception e) {
			e.printStackTrace();
			tx.rollback();
		}
		
		return homes;
	}
}
