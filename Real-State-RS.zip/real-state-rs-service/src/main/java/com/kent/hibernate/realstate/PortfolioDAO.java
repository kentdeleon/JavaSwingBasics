package com.kent.hibernate.realstate;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.ObjectNotFoundException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.kent.realstate.hibernate.entities.Portfolio;

public class PortfolioDAO {

	private SessionFactory sessionFactory = null;
	private Session session = null;
	private Transaction tx = null;
	private List<Portfolio> portfolios = new ArrayList<>();

	public List<Portfolio> getAllPortfolios() {
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			Query query = session.createQuery("FROM Portfolio P");
			portfolios = query.list();

			tx.commit();
			return portfolios;
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			// session.close();
			// sessionFactory.close();

		}
		return null;
	}

	public Portfolio getPortfolioById(long id) {
		Portfolio dbPortfolio = null;

		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			dbPortfolio = (Portfolio) session.get(Portfolio.class, id);
			tx.commit();

		} catch(ObjectNotFoundException e) {
			e.printStackTrace();
			return null;
		}catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return dbPortfolio;
	}

	public Portfolio savePortfolio(Portfolio portfolio) {
		try {
			sessionFactory = HibernateUtil.getSessionFactory();
			session = sessionFactory.openSession();
			tx = session.beginTransaction();

			session.save(portfolio);
			tx.commit();
		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return portfolio;

	}
}
