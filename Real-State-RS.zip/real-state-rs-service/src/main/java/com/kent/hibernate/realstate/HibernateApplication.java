package com.kent.hibernate.realstate;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.kent.realstate.hibernate.entities.Home;
import com.kent.realstate.hibernate.entities.Portfolio;



public class HibernateApplication {

	public static void main(String[] args) {

//		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
//		Session session = sessionFactory.openSession();
////		Transaction tx = session.beginTransaction();
//		
		PortfolioDAO dao = new PortfolioDAO();
		for(int i = 0; i < dao.getAllPortfolios().size(); i++) {
			System.out.println(dao.getAllPortfolios().get(i).getName());
			


			
		}
		
	}
}
