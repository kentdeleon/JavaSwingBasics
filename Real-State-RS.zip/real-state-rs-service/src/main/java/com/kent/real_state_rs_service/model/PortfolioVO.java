package com.kent.real_state_rs_service.model;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class PortfolioVO {

	private Long portfolioId;
	
	private String name;
	
	private List<HomeVO> homes;
	
	public List<HomeVO> getHomes() {
		return homes;
	}

	public void setHomes(List<HomeVO> homes) {
		this.homes = homes;
	}

	public PortfolioVO() {
		
	}
	
	public PortfolioVO(Long portfolioId, String name){
		this.portfolioId = portfolioId;
		this.name = name;
	}

	public Long getPortfolioId() {
		return portfolioId;
	}

	public void setPortfolioId(Long portfolioId) {
		this.portfolioId = portfolioId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
