package com.kent.real_state_rs_service.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.kent.hibernate.realstate.PortfolioDAO;
import com.kent.real_state_rs_service.Exception.PortfolioNotFoundException;
import com.kent.real_state_rs_service.model.PortfolioVO;
import com.kent.realstate.hibernate.entities.Portfolio;

public class PortfolioService {

//	private Map<Long, PortfolioVO> portfolios = new HashMap<>();
//
//	public PortfolioService() {
//		if (portfolios.size() == 0) {
//			portfolios.put(1L, new PortfolioVO(1L, "Avaya Homes"));
//			portfolios.put(2L, new PortfolioVO(2L, "Camella Homes"));
//		}
//	}
	
	private PortfolioDAO portfolioDAO = new PortfolioDAO();
	
	public List<PortfolioVO> getAllPortfolios(){
		
		List<Portfolio> portfolios = portfolioDAO.getAllPortfolios();
		List<PortfolioVO> portfolioVOs = new ArrayList<>();
		
		for(Portfolio portfolio: portfolios) {
			portfolioVOs.add(new PortfolioVO(portfolio.getPortfolioId(), portfolio.getName()));
		}
		
		return portfolioVOs;
	}
	
	public PortfolioVO getPortfolioById(long id) throws PortfolioNotFoundException {
		Portfolio portfolio = portfolioDAO.getPortfolioById(id);
		
		if(portfolio == null) {
			throw new PortfolioNotFoundException("Portfolio with id: " + id + " not found");
		}
		
		return new PortfolioVO(portfolio.getPortfolioId(), portfolio.getName());
	}
	
	public PortfolioVO savePortfolio(PortfolioVO portfolio) {
		
		Portfolio newPortfolio = portfolioDAO.savePortfolio(new Portfolio(portfolio.getName()));
		
		return new PortfolioVO(newPortfolio.getPortfolioId(), newPortfolio.getName());
		
	}
}
