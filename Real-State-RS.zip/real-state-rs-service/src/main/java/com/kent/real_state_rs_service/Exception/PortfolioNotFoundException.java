package com.kent.real_state_rs_service.Exception;

public class PortfolioNotFoundException extends Throwable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1816782495982449452L;

	public PortfolioNotFoundException(String message) {
		super(message);
	}

	


}
