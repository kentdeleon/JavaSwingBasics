package com.kent.real_state_rs_service.resource;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kent.real_state_rs_service.Exception.PortfolioNotFoundException;
import com.kent.real_state_rs_service.model.PortfolioVO;
import com.kent.real_state_rs_service.service.PortfolioService;

@Path("/portfolios")
public class PortfolioResource {

	PortfolioService portfolioService = new PortfolioService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<PortfolioVO> getAllMessages() {
		List<PortfolioVO> portfolios = portfolioService.getAllPortfolios();
				
		return portfolios;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{portfolio_id}")
	public PortfolioVO getPortfolioById(@PathParam("portfolio_id") Long portfolio_id) throws PortfolioNotFoundException {
		return portfolioService.getPortfolioById(portfolio_id);
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public PortfolioVO savePortfolio(PortfolioVO portfolio) {
		return portfolioService.savePortfolio(portfolio);
	}
	
	@Path("/{portfolio_id}/homes")
	public HomeResource homeResource() {
		return new HomeResource();
	}
}

