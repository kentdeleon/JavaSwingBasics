package com.kent.real_state_rs_service.model;

import java.math.BigDecimal;

import com.kent.realstate.hibernate.entities.Address;
import com.kent.realstate.hibernate.entities.HomeAvailabilityType;

public class HomeVO {

	private Long homeId;
	private String name;
	private HomeAvailabilityType availibity;
	private BigDecimal value;
	private Address address;

	public HomeVO() {
		
	}
	public HomeVO(Long homeId, String name, HomeAvailabilityType availibity, BigDecimal value, Address address) {
		this.homeId = homeId;
		this.name = name;
		this.availibity = availibity;
		this.value = value;
		this.address = address;
	}

	public Long getHomeId() {
		return homeId;
	}

	public void setHomeId(Long homeId) {
		this.homeId = homeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HomeAvailabilityType getAvailibity() {
		return availibity;
	}

	public void setAvailibity(HomeAvailabilityType availibity) {
		this.availibity = availibity;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	

}
