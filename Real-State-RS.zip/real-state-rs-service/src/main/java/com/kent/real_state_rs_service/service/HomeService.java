package com.kent.real_state_rs_service.service;

import java.util.ArrayList;
import java.util.List;

import com.kent.hibernate.realstate.HomeDAO;
import com.kent.hibernate.realstate.PortfolioDAO;
import com.kent.real_state_rs_service.model.HomeVO;
import com.kent.real_state_rs_service.model.PortfolioVO;
import com.kent.realstate.hibernate.entities.Home;
import com.kent.realstate.hibernate.entities.Portfolio;

public class HomeService {

	private PortfolioDAO portfolioDAO = new PortfolioDAO();
	private HomeDAO homedao = new HomeDAO();

	public PortfolioVO getAllHomesByPortfolioId(long portfolio_id) {
		List<Home> homes = homedao.getAllHomeByPortfolioId(portfolio_id);
		List<HomeVO> homesVO = new ArrayList<>();
		
		Portfolio portfolio = portfolioDAO.getPortfolioById(portfolio_id);
		PortfolioVO portfolioVO = new PortfolioVO(portfolio.getPortfolioId(), portfolio.getName());
		
			

		for (Home home : homes) {
			homesVO.add(new HomeVO(home.getHomeId(), home.getName(), home.getAvailability(), home.getValue(), home.getAddress()));
		}
		portfolioVO.setHomes(homesVO);
		
		return portfolioVO;
	}
}
