package com.kent.real_state_rs_service.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.kent.real_state_rs_service.model.PortfolioVO;
import com.kent.real_state_rs_service.service.HomeService;

@Path("/")
public class HomeResource {

	private HomeService homeService = new HomeService();

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public PortfolioVO getAllHomesByPortfolioId(@PathParam("portfolio_id") long portfolio_id) {
		return homeService.getAllHomesByPortfolioId(portfolio_id);
	}
}
