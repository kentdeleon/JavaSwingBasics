package com.kent.realstate.hibernate.entities;

public enum HomeAvailabilityType {
	AVAILABLE,
	SOLD,
	RESERVE
}
