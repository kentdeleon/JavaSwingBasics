package com.kent.realstate.hibernate.entities;


import java.math.BigDecimal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="home")
public class Home {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="home_id")
	private Long homeId;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="portfolio_id")
	private Portfolio portfolio;
	
	@Column(name="name")
	private String name;
	
	@Enumerated(EnumType.STRING)
	@Column(name="availability")
	private HomeAvailabilityType availability;
	
	@Column(name="value")
	private BigDecimal value;
	
	@Embedded
	private Address address;

	public Home() {
		
	}
	
	
	public Home(String name, HomeAvailabilityType availability, BigDecimal value) {
		super();
		this.name = name;
		this.availability = availability;
		this.value = value;
	}


	public Long getHomeId() {
		return homeId;
	}

	public void setHomeId(Long homeId) {
		this.homeId = homeId;
	}

	public Portfolio getPortfolio() {
		return portfolio;
	}

	public void setPortfolio(Portfolio portfolio) {
		this.portfolio = portfolio;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public HomeAvailabilityType getAvailability() {
		return availability;
	}

	public void setAvailability(HomeAvailabilityType availability) {
		this.availability = availability;
	}

	public BigDecimal getValue() {
		return value;
	}

	public void setValue(BigDecimal value) {
		this.value = value;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	
}
