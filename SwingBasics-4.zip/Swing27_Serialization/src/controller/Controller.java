package controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import gui.FormEvent;
import model.AgeCategory;
import model.Database;
import model.EmployeeCategory;
import model.Gender;
import model.Person;

public class Controller {

	Database db = new Database();

	public List<Person> getAllPerson() {
		return db.getAllPerson();
	}

	public void addPerson(FormEvent ev) {
		String name = ev.getName();
		String occupation = ev.getOccupation();
		int ageCategoryKey = ev.getAgeCategoryKey();
		String employeeCategory = ev.getEmployeeCategory();
		boolean isUsCitizen = ev.getUsCitizen();
		String gender = ev.getGender();
		String taxId = ev.getTaxId();

		AgeCategory ageCategory = null;

		switch (ageCategoryKey) {
		case 0:
			ageCategory = AgeCategory.child;
			break;
		case 1:
			ageCategory = AgeCategory.adult;
			break;
		case 2:
			ageCategory = AgeCategory.senior;
			break;
		}

		EmployeeCategory employmentCat = null;

		if (employeeCategory.equals("Employed")) {
			employmentCat = EmployeeCategory.employed;
		} else if (employeeCategory.equals("Self-Employed")) {
			employmentCat = EmployeeCategory.selfEmployed;
		} else if (employeeCategory.equals("Unemployed")) {
			employmentCat = EmployeeCategory.unemployed;
		}

		Gender genderCat = null;
		if (gender.equals("male")) {
			genderCat = Gender.male;
		} else if (gender.equals("female")) {
			genderCat = Gender.female;
		}

		Person person = new Person(name, occupation, ageCategory, employmentCat, taxId, isUsCitizen, genderCat);

		db.addPerson(person);
		System.out.println("Adding person to db: "+ person);

	}
	
	public void saveToFile(File file) throws IOException {
		db.saveToFile(file);
	}
	
	public void loadFromFile(File file) throws ClassNotFoundException, IOException {
		db.loadFromFile(file);
	}
}
