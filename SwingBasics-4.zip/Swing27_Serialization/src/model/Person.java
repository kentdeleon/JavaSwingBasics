package model;

import java.io.Serializable;

public class Person implements Serializable{


	private static final long serialVersionUID = -5304966782865976504L;
	
	private static int count = 0;
	private int id;
	private String name;
	private String occupation;
	private AgeCategory ageCategoryKey;
	private EmployeeCategory employeeCategory;
	private String taxId;
	private boolean usCitizen;
	private Gender gender;

	
	public Person(String name, String occupation, AgeCategory ageCategoryKey, EmployeeCategory employeeCategory,
			String taxId, boolean usCitizen, Gender gender) {
		this.name = name;
		this.occupation = occupation;
		this.ageCategoryKey = ageCategoryKey;
		this.employeeCategory = employeeCategory;
		this.taxId = taxId;
		this.usCitizen = usCitizen;
		this.gender = gender;
		this.id = count;
		count++;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public AgeCategory getAgeCategoryKey() {
		return ageCategoryKey;
	}

	public void setAgeCategoryKey(AgeCategory ageCategoryKey) {
		this.ageCategoryKey = ageCategoryKey;
	}

	public EmployeeCategory getEmployeeCategory() {
		return employeeCategory;
	}

	public void setEmployeeCategory(EmployeeCategory employeeCategory) {
		this.employeeCategory = employeeCategory;
	}

	public String getTaxId() {
		return taxId;
	}

	public void setTaxId(String taxId) {
		this.taxId = taxId;
	}

	public boolean isUsCitizen() {
		return usCitizen;
	}

	public void setUsCitizen(boolean usCitizen) {
		this.usCitizen = usCitizen;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Person [id=" + id + ", name=" + name + ", occupation=" + occupation + ", ageCategoryKey="
				+ ageCategoryKey + ", employeeCategory=" + employeeCategory + ", taxId=" + taxId + ", usCitizen="
				+ usCitizen + ", gender=" + gender + "]";
	}
	
	

}
