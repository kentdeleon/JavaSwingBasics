import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class SocServer {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("S: Server is started");
		ServerSocket socketServer = new ServerSocket(9999);
		System.out.println("S: Server is waiting for client request in port 9999");
		Socket s = socketServer.accept();
		System.out.println("S: Client connected");

		BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
		String str = br.readLine();

		System.out.println("S: Client Data: " + str);
		
		//From server to client
		String nickName = str.substring(0, 3);
		
		OutputStreamWriter os = new OutputStreamWriter(s.getOutputStream());
		PrintWriter out = new PrintWriter(os);
		out.println(nickName); 
		out.flush();
		System.out.println("S: Date sent from Server to Client");
	}

}
