import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;

public class SocClient {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		String ip = "127.0.0.1";
		int port = 9999;
		
		Socket s = new Socket(ip, port);
		
		String str = "Navin Reddy";
		
		OutputStreamWriter os = new OutputStreamWriter(s.getOutputStream());
		PrintWriter out = new PrintWriter(os);
		out.println(str); 
		os.flush();
		
		//Fetch data from Server to client
		BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream()));
		String nickName= br.readLine();
		System.out.println("C: Data from Server " + nickName);
	}

}
