package com.kent.socket.portscanner;

import java.io.IOException;
import java.net.Socket;

public class PortScanner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(args[0]);
		Socket s;
		
		for(int i = 1; i < 65536; i++) {
			try {
				s = new Socket(args[0], i);
				System.out.println("Port open: " + i);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
	}

}
