package com.kent.socket.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {
		try {
			Socket s = new Socket("127.0.0.1", 3000);
			
			DataInputStream dataInputStream = new DataInputStream(s.getInputStream());
			
			String msg = dataInputStream.readUTF();
			
			System.out.println("Client Connected!");
			System.out.println(msg);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
