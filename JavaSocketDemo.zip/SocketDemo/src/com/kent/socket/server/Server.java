package com.kent.socket.server;

import java.io.DataOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {
		try {
			ServerSocket server = new ServerSocket(3000);
			Socket s = server.accept();

			System.out.println("Connected to port 3000");
			DataOutputStream dataOutputStream = new DataOutputStream(s.getOutputStream());
			dataOutputStream.writeUTF("Welcome to Socket Programming");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
